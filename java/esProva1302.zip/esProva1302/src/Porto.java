public class Porto {
    private static final int MAX_POSTI = 100;
    private PostoBarca[] vPostiBarca;
    private int progPosto;

    public Porto() {
        vPostiBarca = new PostoBarca[MAX_POSTI];
        progPosto = 0;
    }

    public int getProgPosto() {
        return progPosto;
    }
    public void addPostoBarca(double dataInzio, double dataFine, Barca occupante){
        
    }
    private class PostoBarca{
        private double dataInizio;
        private double dataFIne;
        private Barca occupante;
        private boolean isOccupato;

        public PostoBarca(double dataInizio, double dataFIne, Barca occupante) {
            this.dataInizio = dataInizio;
            this.dataFIne = dataFIne;
            this.occupante = occupante;
        }

        public double getDataInizio() {
            return dataInizio;
        }

        public double getDataFIne() {
            return dataFIne;
        }

        public Barca getOccupante() {
            return occupante;
        }

        public boolean isOccupato() {
            return isOccupato;
        }

        @Override
        public String toString() {
            return "PostoBarca{" +
                    "dataInizio=" + dataInizio +
                    ", dataFIne=" + dataFIne +
                    ", occupante=" + occupante +
                    ", isOccupato=" + isOccupato +
                    '}';
        }
    }
}
