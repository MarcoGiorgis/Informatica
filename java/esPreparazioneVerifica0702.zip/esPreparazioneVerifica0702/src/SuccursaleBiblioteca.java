import java.util.Scanner;
import java.util.Vector;

public class SuccursaleBiblioteca {
    private String nome;
    private String indirizzo;
    private int progScaffale;
    private Vector<Scaffale> vScaffali;
    private Vector<Utente> vUtenti;

    public SuccursaleBiblioteca(String nome, String indirizzo) {
        this.nome = nome;
        this.indirizzo = indirizzo;
        progScaffale = 0;
        vScaffali = new Vector<>();
        vUtenti = new Vector<>();
    }

    public void addScaffale(int numero, TipoArticolo tipo, int max_articoli){
        vScaffali.add(new Scaffale(numero, tipo, max_articoli));
        progScaffale++;
    }

    public void addUtente(Utente u){
        if(u != null && cercaUtente(u) != null){
            vUtenti.add(u);
        }
    }
    public Utente cercaUtente(Utente utente){
        int i = 0;
        int tro = -1;
        while (i < vUtenti.size() && tro == -1){
            if (utente == vUtenti.elementAt(i)){
                tro = i;
            }else{
                i++;
            }
        }
        if (tro != -1)
            return vUtenti.elementAt(tro);
        else
            return null; //eccezione
    }

    public double getValoreTotale(){
        double sommaTotale = 0;
        for(Scaffale s: vScaffali){
            sommaTotale += s.getValoreScaffale();
        }
        return sommaTotale;
    }

    public void prestitoId(String codiceFIscale, int id){
        int k = 0;
        int j = 0;
        Utente tro = null;
        Articolo aId = null;

        while (j < vScaffali.size() && aId == null){
            aId = vScaffali.get(j).cercaArticoloID(id);
            j++;
        }
        while (k < vUtenti.size() && tro != null){
            if(codiceFIscale == vUtenti.get(k).getCodiceFiscale()){
                tro = vUtenti.get(k);
            }
            k++;
        }
        if(tro == null || aId == null){
            //eccezzione
        }
        aId.setInPrestitoA(vUtenti.get(k));
    }

    public void restituireId(int id){
        int j = 0;
        Articolo aId = null;
        while (j < vScaffali.size() && aId == null){
            aId = vScaffali.get(j).cercaArticoloID(id);
            j++;
        }
        if(aId == null){
            //eccezione
        }
        aId.setInPrestitoA(null);
    }
    public String toString(){
        String str = "";
        for(int k = 0; k < vScaffali.size(); k++){
            str += vScaffali.get(k) + "\n";
        }
        return str + " nome: " + nome + " indirizzo: " + indirizzo;
    }

    public class Scaffale{
        private int numero;
        private TipoArticolo tipo;
        private final int MAX_ARTICOLI;
        private static final int DEF_ARTICOLI = 10;
        private Articolo vArticoli[];
        private int nArticoli;

        public Scaffale(int numero, TipoArticolo tipo, int max_articoli) {
            this.numero = numero;
            this.tipo = tipo;
            if(max_articoli > 0)
                MAX_ARTICOLI = max_articoli;
            else
                MAX_ARTICOLI = DEF_ARTICOLI;
            vArticoli = new Articolo[MAX_ARTICOLI];
            nArticoli = 0;
        }

        public boolean addArticolo(Articolo a){
            boolean aggiunto = false;
            if(nArticoli < MAX_ARTICOLI){
                if((a instanceof DVD && tipo == TipoArticolo.DVD) || (a instanceof Libro && tipo == TipoArticolo.LIBRO)){
                    vArticoli[nArticoli] = a;
                    nArticoli++;
                    aggiunto = true;
                }
            }
            return aggiunto;
        }


        public Vector<Articolo> cercaArticoloTitolo(String titolo){
            int k = 0;
            Vector<Articolo> vArticoliCercati = null;
            while (k < nArticoli){
                if(titolo == vArticoli[k].getTitolo()) {
                    vArticoliCercati.add(vArticoli[k]);
                }
                k++;
            }
            if(vArticoliCercati != null) {
                return vArticoliCercati;
            } else {
                return null; //eccezione
            }
        }

        public Articolo cercaArticoloID(int id){
            int k = 0;
            Articolo tro = null;
            while (k < nArticoli && tro != null){
                if(id == vArticoli[k].getIdArticolo()) {
                   tro = vArticoli[k];
                }
                k++;
            }
            if(tro != null)
                return tro;
            else
                return null; //eccezione
        }

        public double getValoreScaffale(){
            double tot = 0;
            for(Articolo a: vArticoli){
                tot += a.getValore();
            }
            return tot;
        }

        public Articolo[] getvArticoli() {
            return vArticoli;
        }

        public String toString(){
            String str = "";
            for(int k = 0; k < nArticoli; k++){
                str += vArticoli[k] + "\n";
            }
            return str + " numero: " + numero + " tipo: " + tipo;
        }
    }
}
