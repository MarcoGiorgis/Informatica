public enum TipoArticolo {
    LIBRO,
    DVD;
}
